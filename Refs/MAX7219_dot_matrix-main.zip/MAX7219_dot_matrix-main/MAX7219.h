/*
 * MAX7219.h
 *
 *  Created on: 16 Jan 2023
 *      Author: EDISON NGUNJIRI
 */

#ifndef MAX7219_H_
#define MAX7219_H_
void Print_Alphabet(void);
void MAX7219_Init(void);
void MAX72_Init_F(void);
#endif /* MAX7219_H_ */
