# MAX7219_dot_matrix
This is a driver for  MAX7219 Dot Matrix. The code prints all alphabets and Numerics 
